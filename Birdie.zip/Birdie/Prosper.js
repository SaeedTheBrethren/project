// Wait for the DOM to load fully
document.addEventListener("DOMContentLoaded", () => {
    // Get the heart element by its ID
    const heart = document.getElementById("heart");

    if (heart) {
        // Add an event listener to the heart for a click event
        heart.addEventListener("click", function () {
            // Add a class to trigger the pulse animation
            heart.classList.add("pulse");

            // Wait for the animation to finish, then proceed to the next page
            setTimeout(function () {
                window.location.href = "birthday.html"; // Redirect to birthday page
            }, 1000); // Wait for 1 second before redirecting
        });
    }

    // Select necessary elements for the birthday page
    const candlesContainer = document.querySelector(".candles");
    const celebrationMessage = document.getElementById("celebration-message");
    const cake = document.querySelector(".cake");

    if (candlesContainer && cake && celebrationMessage) {
        // Dynamically create 19 candles
        for (let i = 0; i < 19; i++) {
            const candle = document.createElement("div");
            candle.classList.add("candle");

            const flame = document.createElement("div");
            flame.classList.add("flame");
            candle.appendChild(flame);

            candlesContainer.appendChild(candle);
        }

        // Blow out candles when the cake is clicked
        cake.addEventListener("click", () => {
            // Remove flames
            document.querySelectorAll(".flame").forEach((flame) => (flame.style.display = "none"));

            // Show celebration message
            celebrationMessage.style.display = "block";

            // Add animation for fun
            celebrationMessage.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 500 });
        });
    }
});
